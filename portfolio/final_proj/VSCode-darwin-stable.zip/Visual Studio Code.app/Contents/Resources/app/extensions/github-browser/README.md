# GitHub FileSystem for Visual Studio Code

**Notice:** This extension is bundled with Visual Studio Code. It can be disabled but not uninstalled.

## Features

This extension provides remote GitHub repository features for VS Code.
