from django.apps import AppConfig


class RecipeAppConfig(AppConfig):
    name = 'recipe_app'
